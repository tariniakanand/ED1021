#include <stdio.h>
#include <string.h>
struct StudentDetails
{
	char name[100];
	int age;
	char rollno[6];
	float m[5];
};
typedef struct StudentDetails SD;
int main()
{
	int n, f = 0;
	SD s[100];
	printf("No of students: ");
	scanf("%d", &n);
	printf("\n\nEnter student Records:\n");
	for (int i = 0; i < n; i++)
	{
		printf("\nName: ");
		scanf_s("%s", &s[i].name);
		printf("Age: ");
		scanf_s("%d", &s[i].age);
		printf("Roll No: ");
		scanf_s("%s", &s[i].rollno);
		for (int j = 0; j < 5; j++)
		{
			printf("Marks %d: ", j + 1);
			scanf_s("%f", &s[f].m[j]);
		}
		printf("\n");
		f = f + 1;
	}
	printf("\nStudent Information:\n");
	f = 0;
	for (int i = 0; i < n; i++)
	{
		printf("\nName: %s  ", s[i].name);
		printf("Age: %d  ", s[i].age);
		printf("Roll No: %s  ", s[i].rollno);
		for (int j = 0; j < 5; j++)
		{
			printf("Marks %d: %f  ", j + 1, s[f].m[j]);
		}
		printf("\n");
		f = f + 1;
	}
}
