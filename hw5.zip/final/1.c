#include <stdio.h>
#include <string.h>
int main()
{
	char name[6] = { 'T', 'a', 'r', 'i', 'n', 'i' };
	printf("a) Name as a string: %s\n\n", name);//a

	printf("b) Name as a set of charecters: ");//b
	for (int i = 0; i < 6; i++)
	{
		printf("%c", name[i]);
	}

	char* ptr;
	ptr = name;
	printf("\n\nc) Name as a set of char using pointers: ");//c
	for (int i = 0; i < 6; i++)
	{
		printf("%c", *(ptr + i));
	}

	char str[100];
	int l;
	printf("\n\nEnter string: ");
	gets_s(str);
	l = strlen(str);
	printf("d) Length of string= %d\n\n", l);//d

	char str1[100], str2[100];
	printf("Enter string 1: ");
	gets_s(str1);
	printf("Enter string 2: ");
	gets_s(str2);
	if (strcmp(str1, str2) == 0)
		printf("Both the strings are the same\n");
	else
		printf("Both the strings are not the same\n");
}