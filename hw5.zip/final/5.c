#include<stdio.h>
#include<string.h>

int main()
{
    char s;
    char* str;
    str = &s;
    printf("Enter a string: ");
    scanf_s("%s", &str);
    printf("Entered string is %s\n", *str);
}
