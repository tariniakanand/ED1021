#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define n 3;
struct StudentDetails
{
	char name[100];
	int age;
	int rollno;
	float m[5];
};
typedef struct StudentDetails SD;
int main()
{
	int f = 0;
	SD s[100];
	printf("Enter student Records:\n");
	for (int i = 0; i < 3; i++)
	{
		printf("Name: ");
		scanf_s("%s", &s[i].name);
		printf("Age: ");
		scanf_s("%d", &s[i].age);
		printf("Roll No: ");
		scanf_s("%d", &s[i].rollno);
		for (int j = 0; j < 5; j++)
		{
			printf("Marks %d: ", j);
			scanf_s("%f", &s[f].m[j]);
		}
		printf("\n");
		f = f + 1;
	}
	printf("\nStudent Information:\n");
	f = 0;
	for (int i = 0; i < 3; i++)
	{
		printf("\nName: %s  ", s[i].name);
		printf("Age: %d  ", s[i].age);
		printf("Roll No: %d  ", s[i].rollno);
		for (int j = 0; j < 5; j++)
		{
			printf("Marks %d: %f  ", j + 1, s[f].m[j]);
		}
		printf("\n");
		f = f + 1;
	}
}

