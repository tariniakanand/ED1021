#include <stdio.h>
#include <string.h>
#define n 3
struct StudentDetails
{
    char name[50];
    int age;
    int rollno;
    float marks[5];
};
typedef struct StudentDetails SD;
int main()
{
    SD s[n];
    printf("Enter Student Records:\n");
    for (int i = 0; i < n; i++)
    {
        printf("\nEnter name: ");
        scanf_s("%s", s[i].name);
        printf("Enter age: ");
        scanf_s("%d", &s[i].age);
        printf("Enter roll number: ");
        scanf_s("%d", s[i].rollno);
        printf("Enter marks in subject 1: ");
        scanf_s("%f", &s[i].marks[1]);
        printf("Enter marks in subject 2: ");
        scanf_s("%f", &s[i].marks[2]);
        printf("Enter marks in subject 3: ");
        scanf_s("%f", &s[i].marks[3]);
        printf("Enter marks in subject 4: ");
        scanf_s("%f", &s[i].marks[4]);
        printf("Enter marks in subject 5: ");
        scanf_s("%f", &s[i].marks[5]);
    }
    float mean1 = 0, mean2 = 0, mean3 = 0, mean4 = 0, mean5 = 0;
    for (int i = 0; i < n; i++)
    {
        mean1 += s[i].marks[1];
        mean2 += s[i].marks[2];
        mean3 += s[i].marks[3];
        mean4 += s[i].marks[4];
        mean5 += s[i].marks[5];
    }
    printf("Average marks of all students in subject 1 is : %f\n", mean1 / 5);
    printf("Average marks of all students in subject 2 is : %f\n", mean2 / 5);
    printf("Average marks of all students in subject 3 is : %f\n", mean3 / 5);
    printf("Average marks of all students in subject 4 is : %f\n", mean4 / 5);
    printf("Average marks of all students in subject 5 is : %f\n", mean5 / 5);
    printf("\nStudent Information:\n");
    for (int i = 0; i < n; i++)
    {
        printf("Name : ");
        printf("%s", s[i].name);
        printf("Age : ");
        printf("%d", s[i].age);
        printf("Roll no : ");
        printf("%d", s[i].rollno);
        printf("Marks in 5 subects : ");
        int net = 0;
        for (int j = 0; j < 5; j++)
        {
            printf("\n%f", s[i].marks[j]);
            net += s[i].marks[j];
        }
        printf("Percentage of this student is : %f", net / 5);
    }

}
