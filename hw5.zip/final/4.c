#include <stdio.h>
#include <string.h>
#define n 3
void changeName();

struct StudentDetails
{
    char name[50];
    int age;
    char rollno[10];
    float marks[5];
};
typedef struct StudentDetails SD;
int main()
{
    int i, j;
    SD s[n];
    for (i = 0; i < n; i++)
    {
        printf("Enter name: ");
        scanf("%s", s[i].name);
        printf("Enter age: ");
        scanf("%d", &s[i].age);
        printf("Enter roll number: ");
        scanf("%s", &s[i].rollno);
        printf("Enter marks in 5 subjects: \n");
        for (j = 0; j < 5; j++)
        {
            scanf("%f", &s[i].marks[j]);
        }
    }

    char change[50];
    printf("Enter the roll number for name change: ");
    scanf("%s", change);
    for (i = 0; i < n; i++)
    {
        j = strcmp(s[i].rollno, change);
        if (j == 0) {
            printf("Before updating name is %s\n", s[i].name);
            changeName(s[i].name);
            printf("After updating name is %s\n", s[i].name);
        }
    }

}

void changeName(char* a)
{
    char newname[25];
    printf("Enter the new name: ");
    scanf("%s", newname);
    strcpy(a, newname);
}