#include <stdio.h>
int main()
{
	// armstrong number abc = a^3 + b^3 + c^3 + d^3
	int n;
	printf("Enter a three digit integer:");
	scanf_s("%d", &n);
	int a, b, c;
	c = n % 10;
	b = (n % 100)/10;
	a = n/100;
	int s1, s2, s3;
	s1 = a * a * a;
	s2 = b * b * b;
	s3 = c * c * c;
	if (n == s1 + s2 + s3)
		printf("The given number is Armstrong number\n");
	else
		printf("The given number is not Armstrong number\n");
}