#include <stdio.h>
int main()
{
	int a, b, max, min;
	printf("a) Enter two numbers a and b:\n");
	scanf_s("%d, %d", &a, &b);
	max = a > b ? a : b;
	printf("%d is the largest number\n", max);
	min = a < b ? a : b;
	printf("%d is the smallest number\n", min);

	int n1, n2, n3, max1, min1;
	printf("b) Enter three numbers n1, n2 and n3:\n");
	scanf_s("%d, %d, %d", &n1, &n2, &n3);
	max1= (n1 > n2) ? (n1 > n3 ? n1 : n3) : (n2 > n3 ? n2 : n3);
	printf("%d is the largest number\n", max1);
	min1= (n1 < n2) ? (n1 < n3 ? n1 : n3) : (n2 < n3 ? n2 : n3);
	printf("%d is the smallest number\n", min1);

}