#include <stdio.h>
int main()
{
	int n;
	printf("Enter an integer:");
	scanf_s("%d", &n);
	if (n % 2 == 0)
		printf("The given integer is even");
	else
		printf("The given integer is odd");
}