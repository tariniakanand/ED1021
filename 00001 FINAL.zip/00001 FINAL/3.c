#include <stdio.h>
int main()
{
	float a, b, c;
	printf("Input three numbers:");
	scanf_s("%f, %f, %f", &a, &b, &c);
	if (a + b > c)
		if (a + c > b)
			if (b + c > a)
				printf("Triangle can be formed\n");
			else
				printf("Traingle cannot be formed\n");
		else
			printf("Traingle cannot be formed\n");
	else
		printf("Traingle cannot be formed\n");
}