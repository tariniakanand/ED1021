#include <stdio.h>
int main()
{
	int time;
	printf("Enter time:");
	scanf_s("%d", &time);
	if (time <= 1440)
	{
		int hours, mins;
		hours = time / 60;
		mins = time % 60;
		printf("%d minutes = %d hours %d minutes\n", time, hours, mins);
	}
	else
	{
		printf("The time limit has been crossed\n");
	}
}