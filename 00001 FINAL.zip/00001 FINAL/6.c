#include <stdio.h>
#include <math.h>
int main()
{
	float a, b, c, D, x1, x2;
	printf("Enter the coefficients of the equation\n");
	scanf_s("%f, %f, %f", &a, &b, &c);
	D = b * b - 4 * a * c;

	if (D > 0)
	{
		printf("The equation has real and distinct roots\n");
		x1 = (-b + sqrt(D)) / (2 * a);
		x2 = (-b - sqrt(D)) / (2 * a);
		printf("Root 1= %f\n", x1);
		printf("Root 2= %f\n", x2);
	}

	else if (D == 0)
	{
		printf("The equation has real and equal roots\n");
		x1 = -b / (2 * a);
		printf("Root= %f\n", x1);
	}

	else
	{
		printf("The roots are imaginary\n");
	}
}