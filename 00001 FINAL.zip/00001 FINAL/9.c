#include <stdio.h>
int main()
{
	int n, i, flag;
	printf("Enter an integer:");
	scanf_s("%d", &n);
	i = 2;
	flag = 1;
	while (i<n)
	{
		if (n % i == 0)
		{
			flag = 0;;
			break;
		}
		i++;
	}
	if (flag)
		printf("%d is a Prime number\n", n);
	else
		printf("%d is not a Prime number\n", n);
}