#include <stdio.h>
int main()
{
	int n, a, rem, rev=0;
	printf("Enter an integer:");
	scanf_s("%d", &n);
	a = n;
	do
	{
		rem = n % 10;
		rev = (rev * 10) + rem;
		n = n / 10;
	}
	while (n > 0);

	if (rev == a)
		printf("%d is a Palindrome\n", a);
	else
		printf("%d is not a Palindrome\n", a);
	
}