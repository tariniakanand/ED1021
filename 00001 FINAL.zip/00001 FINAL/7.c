#include <stdio.h>
int main()
{
	int units;
	float rate;
	printf("Enter number of units: ");
	scanf_s("%d", &units);

	if (units <= 100)
	{
		rate = units * 1.50;
		printf("Bill= %f\n", rate);
	}
	else if (units <= 200)
	{
		rate = 100 * 1.50 + (units - 100) * 2.50;
		printf("Bill= %f\n", rate);
	}
	else
	{
		rate = 100 * 1.50 + 100 * 2.50 + (units - 200) * 3.50;
		printf("Bill= %f\n", rate);
	}
}