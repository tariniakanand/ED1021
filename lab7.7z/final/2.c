#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFFER_SIZE 1000
int main()
{
    FILE* fPtr;
    char buffer[BUFFER_SIZE];
    int totalRead = 0;
    fPtr = fopen("G:\My Drive\Self\Trimester 2\ED1021\lab 6\file.txt", "r");
    if (fPtr == NULL)
    {
        printf("Unable to open file.\n");
        exit(EXIT_FAILURE);
    }
    printf("File opened successfully. Reading file contents line by line. \n\n");
    while (fgets(buffer, BUFFER_SIZE, fPtr) != NULL)
    {
        totalRead = strlen(buffer);
        buffer[totalRead - 1] = buffer[totalRead - 1] == '\n'
            ? '\0'
            : buffer[totalRead - 1];
        printf("%s\n", buffer);
    }
    fclose(fPtr);
}