#include <stdio.h>
int main()
{
	float c = 24, f;
	f = 1.8 * c + 32;
	printf("%f\n", f);
}