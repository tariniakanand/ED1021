#include <stdio.h>
int main()
{
	printf("Unary minus\n");
	printf("Multiplicative % / *\n");
	printf("Additive + - \n");
}