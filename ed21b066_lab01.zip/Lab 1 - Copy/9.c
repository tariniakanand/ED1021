#include <stdio.h>
int main()
{
	float P = 1000, R = 10, T = 2, A, I;
	// A=amount, I= Interest
	I = P * R * T;
	A = P + I;
	printf("Amount=%f, Simple Ineterst=%f\n", A, I);
}