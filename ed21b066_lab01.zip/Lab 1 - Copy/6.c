#include <stdio.h>
int main()
{
	float d1 = 10.0, d2 = 8.7, d3 = 7.6, d4 = 11.1, d5 = 9.5, sum, avg;
	sum = d1 + d2 + d3 + d4 + d5;
	avg = sum / 5;
	printf("Average rainfall=%f\n", avg);

}