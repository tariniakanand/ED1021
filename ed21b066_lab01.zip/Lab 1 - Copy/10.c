#include <stdio.h>
int main()
{
	int n = 12, q2, q3, q5, r2, r3, r5;
	q2 = n / 2;
	q3 = n / 3;
	q5 = n / 5;
	r2 = n - 2 * q2;
	r3 = n - 3 * q3;
	r5 = n - 5 * q5;
	printf("When divided by 2\nQuotient=%d, Remainder=%d\n", q2, r2);
	printf("\n");
	printf("When divided by 3\nQuotient=%d, Remainder=%d\n", q3, r3);
	printf("\n");
	printf("When divided by 5\nQuotient=%d, Remainder=%d\n", q5, r5);

}