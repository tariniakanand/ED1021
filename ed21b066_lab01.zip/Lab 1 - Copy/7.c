#include <stdio.h>
int main()
{
	int n = 3, a, b;
	a = n * n;
	b = a * n;
	printf("%d, %d\n", a, b);
}