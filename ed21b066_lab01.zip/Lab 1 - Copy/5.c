#include <stdio.h>
int main()
{
	int a = 5, b = 4, sum, sub, mul, div, rem;
	sum = a + b;
	sub = a - b;
	mul = a * b;
	div = a / b;
	rem = a - a / b;
	printf("sum=%d, sub=%d, mul=%d, div=%d, rem=%d\n", sum, sub, mul, div, rem);

}