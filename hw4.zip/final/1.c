#include <stdio.h>

// Function prototypes
int AddTwoNums(int a, int b);
int SubTwoNums(int a, int b);
int MulTwoNums(int a, int b);
int DivTwoNums(int a, int b);

// Function for adding two numbers
int AddTwoNums(int a, int b)
{
    int c;
    c = a + b;
    return c;
}

// Function for substracting two numbers
int SubTwoNums(int a, int b)
{
    int c;
    c = a - b;
    return c;
}

int MulTwoNums(int a, int b)
{
    int c;
    c = a * b;
    return c;
}

int DivTwoNums(int a, int b)
{
    int c;
    c = b / a;
    return c;
}


int main() 
{
    int a = 5, b = 10;
    int d = 5, f = 10;
    int c;

    c = AddTwoNums(a, b);
    printf("Sum= %d\n", AddTwoNums(a, b));
    c = AddTwoNums(d, f);
    c = SubTwoNums(a, b);
    printf("Sum of d, f= %d\n", AddTwoNums(d, f));
    printf("Difference of a, b= %d\n", SubTwoNums(d, f));
    c = MulTwoNums(d, f);
    c = MulTwoNums(a, b);
    printf("Product of d and f= %d\n", MulTwoNums(d, f));
    printf("Product of a and b= %d\n", MulTwoNums(d, f));
    c = DivTwoNums(d, f);
    c = DivTwoNums(a, b);
    printf("Quotient of d and f= %d\n", DivTwoNums(d, f));
    printf("Quotient of a and b= %d\n", DivTwoNums(d, f));
}