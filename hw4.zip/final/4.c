#include <stdio.h>
float sum(float x);
int main()
{
	float n;
	printf("Value of n: ");
	scanf_s("%f", &n);
	printf("Sum of first %f numbers is %f", n, sum(n));
}
float sum(float x)
{
	float t;
	int i;
	t = 0;
	for (i = 1; i <= x; i++)
	{
		t = t + i;
	}
	
	return t;
}