#include <stdio.h>
float avg(float a[])
{
	float sum;
	sum = 0;
	int i;
	for (i = 0; i < 5; i++)
	{
		sum = sum + a[i];
	}
	return (sum/5);
}
float change(float a[])
{
	float b;
	b = a[] + 1;
	return b;
}

int main()
{
	float a[5];
	int i;
	for (i = 0; i < 5; i++)
	{
		printf("Enter a[%d]: ", i);
		scanf_s("%f", &a[i]);
	}
	float c, d;
	c = avg(a);
	printf("\n");
	printf("Average of matrix= %f\n\n", c);
	printf("Changed Matrix:\n");
	for (i = 0; i < 5; i++)
	{
		int i;
		d = change(a, i);
		printf("b[%d]= %f\n", i, d);
	}
}
