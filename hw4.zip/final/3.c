#include <stdio.h>
int fact(int x);
int main()
{
	int n, i, c;
	printf("Enter integer n: ");
	scanf_s("%d", &n);
	c = fact(n);
	printf("Factorial of given number is %d\n", c);
}
int fact(int x)
{
	int i, c;
	c = 1;
	for (i = 1; i <= x; i++)
	{
		c = c * i;
	}
	return c;
}