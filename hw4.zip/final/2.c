#include <stdio.h>

// Function prototypes
float AddTwoNums(float a, float b);
float SubTwoNums(float a, float b);
float MulTwoNums(float a, float b);
float DivTwoNums(float a, float b);

// Function for adding two numbers
float AddTwoNums(float a, float b)
{
    float c;
    c = a + b;
    return c;
}

// Function for substracting two numbers
float SubTwoNums(float a, float b)
{
    float c;
    c = a - b;
    return c;
}

float MulTwoNums(float a, float b)
{
    float c;
    c = a * b;
    return c;
}

float DivTwoNums(float a, float b)
{
    float c;
    c = b / a;
    return c;
}


int main()
{
    float a = 5, b = 10;
    float d = 5, f = 10;
    int c;

    c = AddTwoNums(a, b);
    printf("Sum= %f\n", AddTwoNums(a, b));
    c = AddTwoNums(d, f);
    c = SubTwoNums(a, b);
    printf("Sum of d, f= %f\n", AddTwoNums(d, f));
    printf("Difference of a, b= %f\n", SubTwoNums(d, f));
    c = MulTwoNums(d, f);
    c = MulTwoNums(a, b);
    printf("Product of d and f= %f\n", MulTwoNums(d, f));
    printf("Product of a and b= %f\n", MulTwoNums(d, f));
    c = DivTwoNums(d, f);
    c = DivTwoNums(a, b);
    printf("Quotient of d and f= %f\n", DivTwoNums(d, f));
    printf("Quotient of a and b= %f\n", DivTwoNums(d, f));
}