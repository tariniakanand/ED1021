#include <stdio.h>
void print(int* d, size_t l)
{
	for (int i = 0; i < l; ++i)
	{
		printf("%d ", d[i]);
	}
}
int main()
{
	int a[5];
	int l = 5;
	int* d;
	for (int i = 0; i < 5; i++)
	{
		printf("a[%d]= ", i);
		scanf_s("%d", &a[i]);
	}
	printf("The elemnts of array:\n");
	print(a, 5);
}