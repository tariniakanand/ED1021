#include <stdio.h>
int main()
{
	int n1, n2, ans=0;
	char op;
	printf("Enter operation [+ - * / % max min]: ");
	scanf_s("%c", &op);
	printf("Enter two integers: ");
	scanf_s("%d, %d", &n1, &n2);
	switch (op)
	{
	case '+':
		ans = n1 + n2;
		break;

	case '-':
		if (n1 > n2)
			ans = n1 - n2;
		else
			ans = n2 - n1;
		break;

	case '*':
		ans = n1 * n2;
		break;

	case '/':
		if (n1 > n2)
			ans = n1 / n2;
		else
			ans = n2 / n1;
		break;

	case '%':
		if (n1 > n2)
			ans = n1 % n2;
		else
			ans = n2 % n1;
		break;

	case 'max':
		if (n1 > n2)
			ans = n1;
		else
			ans = n1;
		break;

	case 'min':
		if (n1 < n2)
			ans = n1;
		else
			ans = n2;
		break;

	default:
		printf("Invalid input\n");
	}
	printf("Answer= %d\n", ans);
}