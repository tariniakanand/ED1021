#include <stdio.h>
int main()
{
	float n1, n2, ans=0, i, j;
	printf("Enter two numbers: ");
	scanf_s("%f %f", &n1, &n2);
	for (i = 1; i <= n1; i++)
	{
		for (j = 1; j <= n2; j++)
		{
			ans = ans + i * j;
		}
	}
	printf("%f\n", ans);
}