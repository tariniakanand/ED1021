#include <stdio.h>
int main()
{
	int arr[1000], n, i;
	printf("Enter size of array (<1000): ");
	scanf_s("%d", &n);
	for (i = 0; i < n; i++)
	{
		printf("a[%d]= ", i);
		scanf_s("%d", &arr[i]);
	}
	printf("\nEven index elements\n");
	for (i = 0; i < n; i++)
	{
		if (i % 2 == 0)
			continue;
		printf("%d ", arr[i]);
	}
	printf("\nOdd Index elements\n");
	for (i=0; i<n; i++)
	{
		if (i % 2 == 0)
		{
			printf("%d ", arr[i]);
		}
			
	}

}