#include <stdio.h>
int main()
{
	int arr[1000], n, i, p;
	printf("Enter size of array (<1000): ");
	scanf_s("%d", &n);
	printf("Enter the value of p: ");
	scanf_s("%d", &p);
	for (i = 0; i < n; i++)
	{
		printf("a[%d]= ", i);
		scanf_s("%d", &arr[i]);
	}
	for (i = 0; i < n; i++)
	{
		if ((i+1) % p == 0 && i!=0)
		{
			arr[i] = 0;
		}
		printf("%d ", arr[i]);
	}
}