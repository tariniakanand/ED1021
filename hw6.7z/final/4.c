#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
typedef struct studentinfo
{
    char name[30];
    int roll_no;
}si;
si s[100];
si ns[100];
int main() {
    struct studentinfo s[10], ns[10];
    FILE* fptr;
    int i;

    fptr = fopen("studentinfo.txt", "w");
    for (i = 0; i < 10; ++i)
    {
        fflush(stdin);
        printf("Enter name: ");
        scanf("%s", s[i].name);

        printf("Enter roll_no: ");
        scanf("%d", &s[i].roll_no);
    }

    fwrite(s, sizeof(s), 100, fptr);
    fclose(fptr);

    fptr = fopen("studentinfo.txt", "r");
    fread(ns, sizeof(ns), 100, fptr);
    for (i = 0; i < 10; ++i)
    {
        printf("Name: %s\n roll_no: %d ", s[i].name, s[i].roll_no);
    }
    fclose(fptr);
}