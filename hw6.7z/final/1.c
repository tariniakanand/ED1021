#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
struct node
{
	int data;
	struct node* next;
};
//add a node in the beginning
void addf(struct node** headref, int newdata)
{
	struct node* newnode = (struct node*)malloc(sizeof(struct node));
	newnode->data = newdata;
	newnode->next = *headref;
	*headref = newnode;
}
//insert a node
void insert(struct node* prev, int newdata)
{
	if (prev == NULL)
	{
		printf("Invalid\n");
		return;
	}
	struct node* newnode = (struct node*)malloc(sizeof(struct node));
	newnode->data = newdata;
	newnode->next = prev->next;
	prev->next = newnode;
}
//add node at the end
void addb(struct node** headref, int newdata)
{
	struct node* newnode = (struct node*)malloc(sizeof(struct node));
	struct node* last = *headref;
	newnode->data = newdata;
	newnode->next = NULL;
	if (*headref == NULL)
	{
		*headref = newnode;
		return;
	}
	while (last->next != NULL)
	{
		last = last->next;
	}
	last->next = newnode;
	return;
}
//deletes the first node
void del(struct node** headref, int key)
{
	struct node* temp = *headref, * prev;
	if (temp != NULL && temp->data == key)
	{
		*headref = temp->next;
		free(temp);
		return;
	}
	while (temp != NULL && temp->data != key)
	{
		prev = temp;
		temp = temp->next;
	}
	if (temp == NULL)
	{
		return;
	}
	prev->next = temp->next;
	free(temp);
}
void display(struct node* node)
{
	while (node != NULL)
	{
		printf(" %d ", node->data);
		node = node->next;
	}
}
int main()
{
	struct node* head = NULL;
	addb(&head, 2);
	addf(&head, 14);
	addf(&head, 8);
	addb(&head, 20);
	insert(head->next, 2);
	printf("Created list:\n");
	display(head);
	del(&head, 1);
	printf("\nLinked list after deletion:\n");
	display(head);
}

