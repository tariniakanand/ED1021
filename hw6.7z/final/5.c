#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct studentinfo
{
    char name[20];
    int roll;
}SI;
int main()
{
    SI arr_student[10];
    int i;
    FILE* fileptr;
    fileptr = fopen("student_info.csv", "w+");
    if (fileptr == NULL)
    {
        printf("The file does not exist\n");
        exit(1);
    }
    for (i = 0; i < 10; i++)
    {
        printf("Enter name\n");
        fflush(stdin);
        scanf("%s", &arr_student[i].name);
        printf("enter roll number\n");
        fflush(stdin);
        scanf("%d", &arr_student[i].roll);
    }
    printf("data is stored\n");
    for (i = 0; i < 10; i++)
    {
        fprintf(fileptr, "name=%s,", arr_student[i].name);
        fprintf(fileptr, "roll number=%d", arr_student[i].roll);
        printf("\n");
    }
    fclose(fileptr);
}