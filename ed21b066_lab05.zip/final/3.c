#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main()
{
	char a[100], b[100];
	printf("a)\n");
	printf("Enter a string: ");
	scanf("%s", a);
	int l;
	printf("Enter length of string: ");
	scanf("%d", &l);
	for (int i = 0; i<=l; i++)
	{
		b[i] = a[i];
	}
	printf("Copied string: %s\n", b);
	printf("\nb)\n");
	char str1[100], str2[100];
	printf("Enter string 1: ");
	scanf("%s", &str1);
	printf("Enter string 2: ");
	scanf("%s", &str2);
	for(int i=0; str1[i] == str2[i] && str1[i] == '\0'; i++)
    {
		if (str1 == str2)
		{
			printf("Strings are same\n");
		}
		else
		{
			printf("Strings are not same");
		}
	}
	printf("\nc)\n");
	char str[100];
	int l1, i;
	int flag = 0;
	printf("Enter string: ");
	scanf("%s", &str);
	printf("Enter length of string: ");
	scanf("%d", &l1);
	for (i = 0; i < l; i++)
	{
		if (str[i] != str[l - i - 1])
		{
			flag = 1;
			break;
		}
	}
	if (flag)
	{
		printf("%s is not a palindrome\n", str);
	}
	else
	{
		printf("%s is a palindrome\n", str);
	}
}